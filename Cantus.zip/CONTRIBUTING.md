# Contributing to CANTUS

Contributions welcome.

Priority areas:
- Pitch detection
- Onset detection
- Deterministic tokenizer
- Example song programs
